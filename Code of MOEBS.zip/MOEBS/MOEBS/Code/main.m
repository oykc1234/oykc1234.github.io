close all;
clear ; 
clc;
%%
% TestProblem Description:
% A total of 46 multi-objective test functions, details are as follows:
%1-5:ZDT1��ZDT2��ZDT3��ZDT4��ZDT6
%6-12��DTLZ1-DTLZ7
%13-22��wfg1-wfg10
%23-32��uf1-uf10
%33-42��cf1-cf10
%43-46:Kursawe��Poloni��Viennet2��Viennet3
%%
TestProblem=1;%1-46
MultiObj = GetFunInfo(TestProblem);
MultiObjFnc=MultiObj.name;%Problem name
% Parameters
params.Np = 100;        % Population size
params.Nr = 100;        % Repository size
params.maxgen =1000;    % Maximum number of generations
params.ngrid = 10;      % Number of grids in each dimension
params.maxvel = 5;      % Maxmium vel in percentage


% MOEBS
REP = MOEBS(params,MultiObj);
%% Draw the result
figure(2)
if(size(REP.pos_fit,2)==2)
    h_rep = plot(REP.pos_fit(:,1),REP.pos_fit(:,2),'ok'); hold on;
       if(isfield(MultiObj,'truePF'))
            h_pf = plot(MultiObj.truePF(:,1),MultiObj.truePF(:,2),'.r'); hold on;
            legend('MOEBS','RealPareto');
       else
           legend('MOEBS');
       end

        grid on; xlabel('f1'); ylabel('f2');
end
if(size(REP.pos_fit,2)==3)
    h_rep = plot3(REP.pos_fit(:,1),REP.pos_fit(:,2),REP.pos_fit(:,3),'ok'); hold on;
      if(isfield(MultiObj,'truePF'))
            h_pf = plot3(MultiObj.truePF(:,1),MultiObj.truePF(:,2),MultiObj.truePF(:,3),'.r'); hold on;
            legend('MOEBS','RealPareto');
      else
          legend('MOEBS');
      end
        grid on; xlabel('f1'); ylabel('f2'); zlabel('f3');
end
title(MultiObjFnc)
%%
% Display info
disp('Repository fitness values are stored in REP.pos_fit');
disp('Repository particles positions are store in REP.pos');


    