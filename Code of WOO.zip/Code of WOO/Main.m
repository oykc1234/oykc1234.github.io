
clc;
clear all;
close all;
run=1; %% The number of independent repetitions 
MaxIteration=1000; 
PopSize=50;
FunIndex=7
[BestX,BestF,HisBestF,FW_WOO,FA_WOO,SE_WOO]=WOO(FunIndex,MaxIteration,PopSize);
if run == 1
    display(['F_index=', num2str(FunIndex)]);
    display(['Run ', num2str(run),' times ']);
    display(['The FB_WOO is: ', num2str(mean(BestF))]);
    display(['The FW_WOO is: ', num2str(mean(FW_WOO))]);
    display(['The FA_WOO is: ', num2str(mean(FA_WOO))]);
    display(['The SE_WOO is: ', num2str(mean(SE_WOO))]);

    Optimal(FunIndex)=BestF;

    display(['The best solution is: ', num2str(BestX)]);
    if BestF>=0
        semilogy(HisBestF,'r','LineWidth',2);
    else
        plot(HisBestF,'r','LineWidth',2);
    end
    xlabel('Iterations');
    ylabel('Fitness');
    title(['F',num2str(FunIndex)]);

else
    for i=1:1
        parfor i=1:run
            [BestX,BestF,HisBestF,FW_WOO,FA_WOO,SE_WOO]=WOO(FunIndex,MaxIteration,PopSize);
            His(:,i)=HisBestF(end);
            BestF1(i)=BestF;
            FW_CC01(i)=FW_WOO;
            FA_WOO1(i)=FA_WOO;
            SE_WOO1(i)=SE_WOO;
        end

        display(['F_index=', num2str(FunIndex)]);
        display(['Run ', num2str(run),' times ']);
        display(['The FB_WOO is: ', num2str(mean(BestF1))]);
        display(['The FW_WOO is: ', num2str(mean(FW_CC01))]);
        display(['The FA_WOO is: ', num2str(mean(FA_WOO1))]);
        display(['The SE_WOO is: ', num2str(mean(SE_WOO1))]);
    end
end